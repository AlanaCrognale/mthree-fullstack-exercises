Container
    Row
        Col-8 - id: vending-items
            Row
                Col
                    Div class: vending-item
                        class: vending-item-id
                        class: vending-item-name
                        class: vending-item-price
                        class: vending-item-quantity
                    Div
                Col
            Row

        Col-4 - id: vending-actions
            Row
                #MONEY IN
                id: money-input-box

                id: add-dollar-button
                id: add-quarter-button
                id: add-dime-button
                id: add-nickel-button
            Row

            Row
                #MESSAGES
                id: messages-input-box
                id: item-input-box


                id: purchase-button
            Row

            Row
                #CHANGE
                id: change-input-box

                id: change-button
            Row
    Row
Container
