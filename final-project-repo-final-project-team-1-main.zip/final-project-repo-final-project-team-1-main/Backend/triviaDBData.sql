USE triviaDB;

INSERT INTO player VALUES
	('kmbappe7', 'kmbappe7'),
    ('sakurajima.mai', 'sakurajima.mai'),
    ('azusugawa.sakuta', 'azusugawa.sakuta'),
    ('armstrong', 'armstrong'),
    ('lockhart', 'lockhart');
    
INSERT INTO game VALUES
	(1, 'kmbappe7', 'Sports', 15, 10, 3),
    (2, 'kmbappe7', 'General Knowledge', 30, 15, 0),
    (3, 'kmbappe7', 'Animals', 30, 15, 1),
    (4, 'kmbappe7', 'Video Games', 27, 14, 1),
    (5, 'sakurajima.mai', 'Sports', 18, 11, 3),
    (6, 'sakurajima.mai', 'General Knowledge', 7, 5, 3),
    (7, 'sakurajima.mai', 'Animals', 27, 14, 1),
    (8, 'sakurajima.mai', 'Video Games', 4, 4, 3),
    (9, 'azusugawa.sakuta', 'Sports', 12, 8, 3),
    (10, 'azusugawa.sakuta', 'General Knowledge', 26, 13, 2),
    (11, 'azusugawa.sakuta', 'Animals', 3, 3, 3),
    (12, 'azusugawa.sakuta', 'Video Games', 5, 5, 3),
	(13, 'armstrong', 'Sports', 27, 14, 1),
    (14, 'armstrong', 'General Knowledge', 7, 6, 3),
    (15, 'armstrong', 'Animals', 24, 13, 2),
    (16, 'armstrong', 'Video Games', 0, 0, 3),
	(17, 'lockhart', 'Sports', 12, 7, 3),
    (18, 'lockhart', 'General Knowledge', 30, 15, 0),
    (19, 'lockhart', 'Animals', 21, 12, 3),
    (20, 'lockhart', 'Video Games', 8, 6, 3);