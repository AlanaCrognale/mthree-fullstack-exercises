import React, { Component } from "react"
import { Switch, Route } from "react-router-dom"
import DashboardMenu from '../components/DashboardMenu'
import Home from '../components/Home'
import Profile from '../components/Profile'
import Leaderboard from '../components/Leaderboard'
import Header from '../components/DashHeader'

class DashboardPage extends Component {
    render() {
        return (
            <div id="dashboard_page" className="App-page">
                <Header />
                <DashboardMenu />
                <Switch>
                    <Route exact path="/dashboard"
                        component={Home} />
                    <Route path="/dashboard/home"
                        component={Home} />
                    <Route path="/dashboard/profile"
                        component={Profile} />
                    <Route path="/dashboard/leaderboard"
                        component={Leaderboard} />
                </Switch>
            </div>
        )
    }
}

export default DashboardPage
