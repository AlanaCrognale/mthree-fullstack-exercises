import React from 'react';
import {Container, Col, Row, Button, ButtonGroup, Card} from 'react-bootstrap';
import 'bootstrap/dist/css/bootstrap.min.css';

import ExitModal from '../components/ExitModal';
import { NavLink } from 'react-router-dom';
import { view } from '@risingstack/react-easy-state'

import '../styles/GamePage.css'

//import { view } from "react-easy-state";
import bigbrainstore from "../stores/Store"
import gameLogo from '../logo.png'
import heart from '../images/heart.png'
import emptyHeart from '../images/emptyHeart.png'
import gameOver from '../images/game-over.png'

const rounds = ["Easy", "Medium", "Hard"]
class GamePage extends React.Component {

    constructor(props) {
        super(props);
        this.state = {
            score: 0,
            questionsCorrect: 0,
            questionsIncorrect: 0,
            lives: 3,
            round: 1,
            questionNumber: 1,
            showExitModal: false,
            showCorrectAnswer: false,
            showGetResults: false,
            gameId: '',
            cardStyle: ""
        };
    }
    //store: playerName, category, questions - Sync methods w/ Ben

    static defaultProps = {
        category: 'TESTING 1 2 3',
        easyQuestions: {results: [
                {category: 'Test',
                type: 'multiple',
                difficulty: 'easy',
                question: 'Works?',
                correct_answer: 'Yep!',
                incorrect_answers: ['No', 'Nah', 'Heck no']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'easy',
                question: 'Works #2?',
                correct_answer: 'Thank Goodness!',
                incorrect_answers: ['Aw, Fudge', 'Youre kidding me', 'Son of a-']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'easy',
                question: 'Are you absolutely sure?',
                correct_answer: 'Darn it, yes!',
                incorrect_answers: ['Ridiculous', 'The nerve of some people', 'I mean, honestly-']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'easy',
                question: 'But what if youre wrong?',
                correct_answer: 'Then I learn something new',
                incorrect_answers: ['Time to give up and/or cry', 'Throw in the towel', 'Well, thats nothing new, now, is it?']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'easy',
                question: 'Last one, are you okay?',
                correct_answer: 'I will be',
                incorrect_answers: ['Define okay', '*sarcastic* Yeah, just peachy', 'Its fine. Everything is fine.']}

        ]},
        mediumQuestions: {results: [
                {category: 'Test',
                type: 'multiple',
                difficulty: 'medium',
                question: 'Pull correct?',
                correct_answer: 'Yeah!',
                incorrect_answers: ['No!', 'Why?', 'Help!']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'medium',
                question: 'Works #2?',
                correct_answer: 'Thank Goodness!',
                incorrect_answers: ['Aw, Fudge', 'Youre kidding me', 'Son of a-']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'medium',
                question: 'Are you absolutely sure?',
                correct_answer: 'Darn it, yes!',
                incorrect_answers: ['Ridiculous', 'The nerve of some people', 'I mean, honestly-']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'medium',
                question: 'But what if youre wrong?',
                correct_answer: 'Then I learn something new',
                incorrect_answers: ['Time to give up and/or cry', 'Throw in the towel', 'Well, thats nothing new, now, is it?']},
                {category: 'Test',
                type: 'multiple',
                difficulty: 'medium',
                question: 'Last one, are you okay?',
                correct_answer: 'I will be',
                incorrect_answers: ['Define okay', '*sarcastic* Yeah, just peachy', 'Its fine. Everything is fine.']}

        ]},
        hardQuestions: {results: [
                {category: 'Test',
                type: 'multiple',
                difficulty: 'hard',
                question: 'Centered?',
                correct_answer: 'Finally!',
                incorrect_answers: ['Stop', 'Go', '%$#@!']}

        ]}
    }

    async componentDidMount(){
        await fetch('http://localhost:8080/api/bigbraintrivia/game/' + bigbrainstore.currentUser + '/' + bigbrainstore.category, {
                mode: "cors",
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                }})
        .then(response => response.json())
        .then(data => {
          console.log('New Game Id:', data);
          this.setState({gameId: data});
          bigbrainstore.setGameId(data);
        })
        .catch((error) => {
          console.log('Game Data Load Error:');
          console.log(error);
        });

        switch(bigbrainstore.category){
            case "Animals":
                this.setState({cardStyle: "question-card-animals"})
                break
            case "General Knowledge":
                this.setState({cardStyle: "question-card-general-knowledge"})
                break
            case "Sports":
                this.setState({cardStyle: "question-card-sports"})
                break
            case "Video Games":
                this.setState({cardStyle: "question-card-video-games"})
                break
            default:
        }
    }


    //"randomizes" placement of right, wrong answers
    randomizeAnswers = (correct_answer, incorrect_answers) => {
        var answers = [correct_answer.replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"'), incorrect_answers[0].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"'), incorrect_answers[1].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"'), incorrect_answers[2].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"')];
        answers.sort(); //order alphabetically
        return answers;
    }

    //handles answer button, both right & wrong
    handleAnswer = (event) => {
        var answerKey = this.questionPull()[1].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"');
        //if right answer
        if (event.target.value === answerKey){
            //mark answer as correct (ideal: color correct button, set all to disabled)
            event.target.style.backgroundColor ='green';
            this.setState({questionsCorrect: this.state.questionsCorrect + 1});
            //update score
            var number = 1;
            if (this.state.round === 2){
                number = number*2;
            }
            else if (this.state.round === 3){
                number = number*3;
            }
            this.setState({score: this.state.score + number});

            //Resets background color after 3 seconds
            setTimeout(function() {
                event.target.style.backgroundColor ='';
            }, 3000);

            //update question after 3 seconds
            setTimeout(() => this.updateQuestion(), 3000);
        }

        //if wrong answer
        else{
            //mark answer as incorrect
            event.target.style.backgroundColor ='red';
            this.setState({showCorrectAnswer: true});
            this.setState({questionsIncorrect: this.state.questionsIncorrect + 1});
            //update lives
            this.setState({lives: this.state.lives - 1});
            //check for end game
            if (this.state.lives === 1){
                this.setState({questionsIncorrect: this.state.questionsIncorrect + 1});
                this.gameEnd();
            }
            else {
                //Resets background color after 3 seconds
                setTimeout(function() {
                    event.target.style.backgroundColor ='';
                }, 3000);

                //hides correct answer after 3 seconds
                setTimeout(() => this.setState({showCorrectAnswer: false}), 3000);

                //update question after 3 seconds
                setTimeout(() => this.updateQuestion(), 3000);
            }
        }
    }

    updateQuestion = () => {
            var cardStyle = this.state.cardStyle
            // update questionNumber & round
            // check if game ended
            if (this.state.questionNumber === 5 && this.state.round === 3){
                this.gameEnd();
            }
            //check if round ended
            else if (this.state.questionNumber === 5){
                this.setState({round: (this.state.round + 1)});
                this.setState({questionNumber: 1,  cardStyle: cardStyle + " spinning-card"});
                setTimeout(()=>this.stopSpin(cardStyle), 1000)
            }
            else {
                this.setState({questionNumber: this.state.questionNumber + 1, cardStyle: cardStyle + " spinning-card"});
                console.log(this.state.cardStyle)
                setTimeout(()=>this.stopSpin(cardStyle), 1000)
            }
            console.log('Checking round, question updated: ' + this.state.round, this.state.questionNumber);

            //setState re-render triggers pull new question and randomize buttons

            //hide Next Question button
            this.setState({showNextQuestion: false});
    }
    stopSpin = (cardStyle) => {
        console.log("stopSpin method")
        this.setState({cardStyle: cardStyle})
    }

    //pull question
    //questionNumber -1 to adjust for index start 0
    questionPull = () => {
        var number = this.state.questionNumber - 1;
        if (this.state.round === 1){
            return [bigbrainstore.easyQuestions[number].question,
            bigbrainstore.easyQuestions[number].correct_answer,
            bigbrainstore.easyQuestions[number].incorrect_answers];
        }
        else if (this.state.round === 2){
            return [bigbrainstore.mediumQuestions[number].question,
            bigbrainstore.mediumQuestions[number].correct_answer,
            bigbrainstore.mediumQuestions[number].incorrect_answers];
        }
        else if (this.state.round === 3){
            return [bigbrainstore.hardQuestions[number].question,
            bigbrainstore.hardQuestions[number].correct_answer,
            bigbrainstore.hardQuestions[number].incorrect_answers];
        }
    }

    handleLives = () =>{
        if (this.state.lives === 3){
            return (<div>
                    <img src={heart} className="Full-heart" alt="heart" />
                    <img src={heart} className="Full-heart" alt="heart" />
                    <img src={heart} className="Full-heart" alt="heart" />
                    </div>);
        }
        else if (this.state.lives === 2){
            return (<div>
                    <img src={heart} className="Full-heart" alt="heart" />
                    <img src={heart} className="Full-heart" alt="heart" />
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    </div>);
        }
        else if (this.state.lives === 1){
            return (<div>
                    <img src={heart} className="Full-heart" alt="heart" />
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    </div>);
        }
        else {
           return (<div>
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    <img src={emptyHeart} className="Empty-heart" alt="empty" />
                    </div>);
        }
    }

    handleExitModalOpen = (event) => {
        console.log("Opening Exit Modal");
        if (event) event.preventDefault();
        this.setState({ showExitModal : true});
    }

    handleExitModalClose = (event) => {
        console.log("Closing Exit Modal");
        this.setState({ showExitModal : false});
    }

    gameEnd = () => {
        console.log("Saving game score, statistics");

        var stats = { gameId: this.state.gameId, name: bigbrainstore.currentUser, category: bigbrainstore.category, score: this.state.score, correct: this.state.questionsCorrect, wrong: this.state.questionsIncorrect };

        fetch('http://localhost:8080/api/bigbraintrivia/game/' + this.state.gameId, {
                mode: 'cors',
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(stats)
                })
        .catch((error) => {
          console.log('Game Data Load Error:');
          console.log(error);
        });
        //alert user game is over, point to results
        this.setState({showGetResults: true});
    }

    stringFormatter (string) {
        string.replace('&quot;', '"')
        string.replace("&#039;", "'")
        return string
    }

    render(){
        return(<Container className="game-container">
                <br />
            <div className="game-header">
                <Row>
                    <Col style={{paddingTop: "45px"}} className='text-center'>
                        <img src={gameLogo} className="Game-logo" alt="logo" />
                    </Col>
                    <Col className='text-center category-title'>
                        {bigbrainstore.category}
                    </Col>
                    <Col style={{paddingTop: "60px"}}>
                        <Button variant="danger"
                                value='exit'
                                onClick={this.handleExitModalOpen}>
                                Exit Game</Button>
                    </Col>
                </Row>
                <br />
                <Row>
                    <Col className='text-center lives'>
                        {this.handleLives()}
                        Lives: {this.state.lives}
                    </Col>
                    <Col className='text-center'>
                    </Col>
                    <Col className='text-center score'>
                        Score: {this.state.score}
                    </Col>
                </Row>
            </div>
                <br />
                <Row>
                    <Col className='text-center round-info'>
                        Round {this.state.round-1 + 1} | Question {this.state.questionNumber}
                    </Col>
                </Row>
                <br />
                <Row>
                    <Col>
                    </Col>
                    <Col>
                    <Card className={this.state.cardStyle}>
                        <Card.Body>
                            <Card.Text className="card-question">
                                <div>{this.questionPull()[0].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"')}</div>
                            </Card.Text>
                        </Card.Body>
                    </Card>
                    </Col>
                    <Col>
                    </Col>
                </Row>
                <br />
                <br />
                <Row>
                    <Col>
                    </Col>
                    <Col>
                        <Button variant="info" className="answer"
                                value={this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[0]}
                                onClick={this.handleAnswer}>
                                {this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[0]}</Button>
                    </Col>
                    <Col>
                        <Button variant="info" className="answer"
                                value={this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[1]}
                                onClick={this.handleAnswer}>
                                {this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[1]}</Button>
                    </Col>
                    <Col>
                    </Col>
                </Row>
                <br/>
                <Row>
                    <Col>
                    </Col>
                    <Col>
                            <Button variant="info" className="answer"
                                value={this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[2]}
                                onClick={this.handleAnswer}>
                                {this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[2]}</Button>
                    </Col>
                    <Col>
                            <Button variant="info" className="answer"
                                value={this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[3]}
                                onClick={this.handleAnswer}>
                                {this.randomizeAnswers(this.questionPull()[1], this.questionPull()[2])[3]}</Button>

                    </Col>
                    <Col>
                    </Col>
                </Row>
                <br />
                <br />
                <Row>
                    <Col>
                    </Col>
                    <Col>
                        { this.state.showCorrectAnswer ? <div className="correct-answer-reveal"><h2>The correct answer is: {this.questionPull()[1].replaceAll('&quot;', '"').replaceAll("&#039;", "'").replaceAll('&ldquo;', '"').replaceAll('&rdquo;', '"')}</h2></div>: null}

                        <br />
                        { this.state.showGetResults ? <div><img src={gameOver}  alt="game over" />
                            <div className="game-over"><br/><br/><NavLink to='/results' className="to-result">Go to results</NavLink><br/><br/></div></div>: null }
                    </Col>
                    <Col>
                    </Col>
                </Row>
                <ExitModal
                show={this.state.showExitModal}
                handleClose={this.handleExitModalClose}/>
        </Container>);
    }
};

export default view(GamePage);
