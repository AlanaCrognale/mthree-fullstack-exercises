import React, { Component } from "react"
import { Switch, Route } from "react-router-dom"
import './App.css'
import WelcomePage from './pages/WelcomePage'
import DashboardPage from './pages/DashboardPage'
import GamePage from './pages/GamePage'
import ResultsPage from './pages/ResultsPage'

class App extends Component {
  render() {
    return (
      <div className="App">
        <main>
          <Switch>
            <Route exact path='/' component={WelcomePage} />
            <Route path='/dashboard' component={DashboardPage} />
            <Route path='/game' component={GamePage} />
            <Route path='/results' component={ResultsPage} />
          </Switch>
        </main>
      </div>
    )
  }
}

export default App