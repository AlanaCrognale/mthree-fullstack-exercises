import React, {Component} from 'react';

class Timer extends Component{
  constructor(props){
    super(props);
    this.state = {
      curMin: 25,
      curSec: '00',
      numCountdowns: 0,
      numPauses: 0,
      running: 'false',
      countOrPause: 'c'
    };
  }
toggleTimer = () => {
  if (this.state.running === 'false'){ //start timer
    this.setState({running: 'true'});
    this.runTimer();
  }
  else{ //stop timer
    this.setState({running: 'false'});
    this.pauseTimer();
  }
}

runTimer = () =>{

  this.interval = setInterval(() => {

    if (this.state.curSec === '00'){
      if (this.state.curMin === 0){
        if (this.state.countOrPause === 'c'){//end of countdown
          this.setState({countOrPause: 'p', curMin: 5, numCountdowns: this.state.numCountdowns+1});
        }
        else{//end of pause
            this.setState({countOrPause: 'c', curMin: 25, numPauses: this.state.numPauses+1});
        }
      }
      this.setState({curMin: this.state.curMin-1})
      this.setState({curSec: '59'});

    }
    else if (parseInt(this.state.curSec)>10){
      this.setState({curSec: parseInt(this.state.curSec)-1});
    }
    else{
      var secs = '0'+(parseInt(this.state.curSec)-1).toString();
      this.setState({curSec: secs});
    }

  },1000);

}

pauseTimer = () =>{
  clearInterval(this.interval);
}


render(){
  return (
    <div>
    <div id="curTime"> {this.state.curMin}:{this.state.curSec} </div>
    <button id="toggleTimer" type="button" onClick={this.toggleTimer}>Start/Stop Timer</button>
    <div id="numCountdowns"> Number of Countdowns: {this.state.numCountdowns}</div>
    <div id="numRests"> Number of Pauses: {this.state.numPauses}</div>
    </div>
  );
}

}

export default Timer;
