import React, {Component} from 'react';
import Product from './Product';


class ProductList extends Component{
  constructor(props){
    super(props);

    const prod1 = <Product name="Product" upvotes={Math.floor(Math.random()*100)} downvotes={Math.floor(Math.random()*100)}></Product>;
    const prod2 = <Product name="Some Product" upvotes={Math.floor(Math.random()*100)} downvotes={Math.floor(Math.random()*100)}></Product>;
    const prod3 = <Product name="Another Product" upvotes={Math.floor(Math.random()*100)} downvotes={Math.floor(Math.random()*100)}></Product>;
    this.state = {
      products: [prod1, prod2, prod3]
    };
  }

  sortAsc = () => {
    var prodArray = this.state.products;
    prodArray.sort(function(a,b){
      return a.props.upvotes-b.props.upvotes;
    })
    this.setState(prodArray);
  }

  sortDesc = () => {
    var prodArray = this.state.products;
    prodArray.sort(function(a,b){
      return b.props.upvotes-a.props.upvotes;
    })
    this.setState(prodArray);
  }

render(){
  return (
    <div >
      <button id="upBtn" type="button" onClick={this.sortAsc}>Sort by Upvotes Ascending</button>
      <button id="downBtn" type="button" onClick={this.sortDesc}>Sort by Upvotes Descending</button>
      <p>{this.state.products}</p>
    </div>
  );
}

}

export default ProductList;
