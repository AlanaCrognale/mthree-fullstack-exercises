import React, {Component} from 'react';

class Product extends Component{
  constructor(props){
    super(props);
  }

render(){
  return (
    <div >
      <div className = "product-element" id="prod">
        <p>{this.props.name}<br/>Upvotes: {this.props.upvotes}<br/> Downvotes: {this.props.downvotes}</p>
      </div>
    </div>
  );
}

}

export default Product;
