import React from 'react';
import logo from './logo.svg';
import './App.css';
import Product from './Product';
import ProductList from './ProductList';

function App() {
  return (
    <div className="App">
      <header className="App-header">
      <ProductList></ProductList>
      </header>
    </div>
  );
}

export default App;
