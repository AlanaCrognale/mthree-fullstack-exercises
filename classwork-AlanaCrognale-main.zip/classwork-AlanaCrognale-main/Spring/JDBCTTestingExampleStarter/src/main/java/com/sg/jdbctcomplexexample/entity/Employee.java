package com.sg.jdbctcomplexexample.entity;

/**
 *
 * @author kylerudy
 */
public class Employee {
    int id;
    String firstName;
    String lastName;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if (!(obj instanceof Employee)) return false;
        Employee e = (Employee) obj;
        return (e.id == this.id && e.firstName.equals(this.firstName) && e.lastName.equals(this.lastName));
    }

    @Override
    public int hashCode() {
        return this.id;
    }

}
