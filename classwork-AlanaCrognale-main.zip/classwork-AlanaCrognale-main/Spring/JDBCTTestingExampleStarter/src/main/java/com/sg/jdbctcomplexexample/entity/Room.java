package com.sg.jdbctcomplexexample.entity;

import com.sg.jdbctcomplexexample.dao.RoomDaoDB;

/**
 *
 * @author kylerudy
 */
public class Room {
    int id;
    String name;
    String description;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @Override
    public boolean equals(Object obj) {
        if(this == obj) return true;
        if (!(obj instanceof Room)) return false;
        Room r = (Room) obj;
        return (r.id == this.id && r.name.equals(this.name) && r.description.equals(this.description));
    }

    @Override
    public int hashCode() {
        return this.id;
    }
}