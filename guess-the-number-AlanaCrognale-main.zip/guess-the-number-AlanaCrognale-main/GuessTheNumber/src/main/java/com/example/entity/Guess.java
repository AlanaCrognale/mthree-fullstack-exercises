package com.example.entity;

public class Guess {
        private int guess;
        private int gameId;

        public int getGuess() {
        return guess;
    }

        public void setGuess(int guess) {
        this.guess = guess;
    }

        public int getGameId() {
        return gameId;
    }

        public void setGameId(int gameId) {
        this.gameId = gameId;
    }

}
